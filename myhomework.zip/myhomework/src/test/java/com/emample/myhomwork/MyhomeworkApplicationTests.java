package com.emample.myhomwork;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MyhomeworkApplicationTests {

	@Test
	void contextLoads() {
	}

}
