package com.emample.myhomwork;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
@Service
@RestController
public class PersonController {
	@Autowired
	private PersonRepository personRepository;
	
	// get all person
	@GetMapping("/persons")
	public List<Person> getAllPerson(){
		return personRepository.findAll();
	}
	
	@PostMapping("/persons")
	public Person createEmployee(@RequestBody Person person) {
		return personRepository.save(person);
	}
	@GetMapping("/persons/{id}")
	public ResponseEntity<Person> getEmployeeById(@PathVariable Long id) {
		Person person = personRepository.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("person not exist with id :" + id));
		return ResponseEntity.ok(person);
	}
	
	// update person rest Api
		@PutMapping("/persons/{id}")
		public ResponseEntity<Person> updatePerson(@PathVariable Long id, @RequestBody Person personDetails){
			Person person = personRepository.findById(id)
					.orElseThrow(() -> new ResourceNotFoundException("person not exist with id :" + id));
			
			person.setName(personDetails.getName());
			person.setAddress(personDetails.getAddress());
			person.setAge(personDetails.getAge());
			person.setId(personDetails.getId());
			Person updatedPerson = personRepository.save(person);
			return ResponseEntity.ok(updatedPerson);
		}
		
		// delete employee rest api
		@DeleteMapping("/employees/{id}")
		public ResponseEntity<Map<String, Boolean>> deleteEmployee(@PathVariable Long id){
			Person person = personRepository.findById(id)
					.orElseThrow(() -> new ResourceNotFoundException("Employee not exist with id :" + id));
			
			personRepository.delete(person);
			Map<String, Boolean> response = new HashMap();
			response.put("deleted", Boolean.TRUE);
			return ResponseEntity.ok(response);
		}
}
	
