package com.emample.myhomwork;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MyhomeworkApplication {

	public static void main(String[] args) {
		SpringApplication.run(MyhomeworkApplication.class, args);
	}

}
